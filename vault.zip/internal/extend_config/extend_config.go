package extend_config

import (
	"fmt"
	"io/ioutil"

	"path/filepath"
	"strings"

	"vault-api/tools/base_config"
	api "vault-api/tools/go-base-api"
	"vault-api/tools/pkg/logging"
	"vault-api/tools/siem"
	trace "vault-api/tools/trace-lib"
	"vault-api/tools/vault"

	"github.com/imdario/mergo"
	"github.com/pkg/errors"
	"gopkg.in/yaml.v3"
)

type C struct {
	// Базовая конфигурация
	base_config.ApplicationConfig `json:"app" yaml:"app"`
	// Валидатор JWT
	Token api.ValidateConf `json:"token" yaml:"token"`
	// Jaeger трассировка
	Trace trace.ProviderConfig `json:"trace" yaml:"trace"`
	// Web-сервер
	API api.ApiServer `json:"api" yaml:"api"`
	// Конфигурация Vault
	Vaults vault.Vaults `json:"vault" yaml:"vault"`
	// Конфигурация SIEM
	Siem siem.SiemConfig `json:"siem" yaml:"siem"`
}

// Описание расширенной конфигурации
func (conf *C) GetParamsFromYml(path string) error {
	if path == "" {
		if conf.ProfileName == "" {
			path, _ = filepath.Abs("./application.yml")
		} else {
			path, _ = filepath.Abs(fmt.Sprintf("./application-%s.yml", conf.ProfileName))
		}
	}
	logging.Log.Info("[EXT:GetParamsFromYml]:: Load file: ", path)
	yamlFile, err := ioutil.ReadFile(path)
	if err != nil {
		logging.Log.Fatal(errors.Wrapf(err, "ReadFile"))
		return err
	}
	err = yaml.Unmarshal(yamlFile, &conf)
	if err != nil {
		logging.Log.Fatal(errors.Wrapf(err, "Unmarshal"))
		return err
	}
	err = mergo.MergeWithOverwrite(&C{}, conf)
	if err != nil {
		logging.Log.Fatal(errors.Wrapf(err, "MergeWithOverwrite"))
		return err
	}
	return nil
}

// Получение параметров из файла конфигурации
func (conf *C) ReloadConfig() {
	logging.Log.Info("[EXT:ReloadConfig]:: Start func ReloadConfig")
	ConfServerURI := base_config.GetValueByNameFromEnv("OMNI_GLOBAL_SPRING_CLOUD_CONFIG_URI")
	AppName := base_config.GetValueByNameFromEnv("APP_NAME")
	ProfileName := base_config.GetValueByNameFromEnv("PROFILE_NAME")
	if ConfServerURI != "" {
		conf.ConfServerURI = ConfServerURI
	}
	if AppName != "" {
		conf.AppName = AppName
	}
	if ProfileName != "" {
		conf.ProfileName = ProfileName
	}
	err := conf.GetParamsFromYml("")
	if err != nil {
		logging.Log.Fatal(errors.Wrapf(err, "GetParamsFromYml"))
	}
	if ProfileName != "develop" && conf.ConfServerURI != "" {
		logging.Log.Info("[EXT:ReloadConfig]:: Use config from cloud")
		conf.ParseCloudFile()

	}

	secrets, file, err := conf.GetSecretsFromJson("")
	if err != nil {
		logging.Log.Error("[EXT:ReloadConfig]:: ", err)
	} else {
		logging.Log.Infof("[EXT:ReloadConfig]:: Use credential's from different file %v\n", file)
		conf.Secrets = secrets
		conf.ReloadPassword()
	}
	if conf.LogLevel == "" {
		conf.LogLevel = "Error"
	}
	logging.ChangeLogLevel(conf.LogLevel)
	logging.Log.Info(conf.LogLevel)
	if strings.ToLower(conf.LogLevel) == "debug" {
		conf.PrintConfigToLog()
	}
}

// Обновление конфигурации
func (conf *C) ParseCloudFile() {
	cloudConfig := &C{}
	backupConfig := conf
	logging.Log.Info("[EXT:parseCloudFile]::", conf.AppName, conf.ProfileName)
	if conf.ConfServerURI == "" {
		logging.Log.Fatal("[EXT:parseCloudFile]:: ConfServerURI is empty")
	}
	rawBytes, err := base_config.FetchFileFromCloud(conf.AppName, conf.ProfileName, conf.ConfServerURI)
	if err != nil {
		logging.Log.Fatal("[EXT:parseCloudFile]:: FetchFileFromCloud: ", err)
	}
	if rawBytes != nil {
		err = yaml.Unmarshal(rawBytes, cloudConfig)
		if err != nil {
			logging.Log.Error(string(rawBytes))
			logging.Log.Fatal(errors.Wrapf(err, "Unmarshal"))
		}
		err := mergo.MergeWithOverwrite(conf, cloudConfig)
		if err != nil {
			logging.Log.Fatal(errors.Wrapf(err, "MergeWithOverwrite"))
		}
	}
	if conf.LogLevel != "" {
		conf.LogLevel = backupConfig.LogLevel
	}
	conf.ProfileName = backupConfig.ProfileName
	conf.ConfServerURI = backupConfig.ConfServerURI
}

// Маппинг паролей
func (conf *C) ReloadPassword() {
	for k, v := range conf.Secrets {
		if v != "" {
			switch k {
			// case "vault_password":
			// 	conf.Vault.Token = v
			default:
				for i, data := range conf.Vaults.Sets {
					name := fmt.Sprintf("vault_%s_password", i)
					role := fmt.Sprintf("%s_role_id", i)
					secret := fmt.Sprintf("%s_secret_id", i)
					if name == k {
						data.Token = v
						conf.Vaults.Sets[i] = data
					}
					if role == k {
						data.RoleId = v
						conf.Vaults.Sets[i] = data
					}
					if secret == k {
						data.SecretId = v
						conf.Vaults.Sets[i] = data
					}
				}
			}
		}
	}
}
