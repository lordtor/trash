package go_base_api

import (
	"context"
	"fmt"
	"net/http"
	"vault-api/docs"
	common_lib "vault-api/tools/common_lib"
	muxprom "vault-api/tools/mux-prometheus/pkg/middleware"
	trace "vault-api/tools/trace-lib"

	"github.com/creasty/defaults"
	"github.com/gorilla/handlers"
	"github.com/gorilla/mux"
	"github.com/imdario/mergo"
	swagger "github.com/swaggo/http-swagger"
	"go.opentelemetry.io/contrib/instrumentation/net/http/otelhttp"

	"github.com/prometheus/client_golang/prometheus/promhttp"
)

// Обновление конфигурации веб-сервера
// Значения по умолчанию перезаписываются переопределенными значениями из
// конфигурации итогового сервиса
func (con *ApiServerConfig) ApiServerConfigUpdate(ctx context.Context, conf ApiServerConfig, config interface{}) {
	err := mergo.MapWithOverwrite(con, conf)
	if err != nil {
		Log.Errorf("[ApiServerConfigUpdate]: %v", handleError(err, "MapWithOverwrite"))
	}
	con.AppConfig = config
}

// Инициализация конфигурации веб-сервера
// Проставление значений по умолчанию
func (con *ApiServerConfig) InitializeApiServerConfig(conf ApiServer) {

	//conf.Defaults.init()
	if defaults.CanUpdate(con.ListenPort) { // Check if it's a zero value (recommended)
		con.ListenPort = conf.Defaults.ListenPort // Set a dynamic value
	}
	if defaults.CanUpdate(con.WriteTimeout) { // Check if it's a zero value (recommended)
		con.WriteTimeout = conf.Defaults.WriteTimeout // Set a dynamic value
	}
	if defaults.CanUpdate(con.ReadTimeout) { // Check if it's a zero value (recommended)
		con.ReadTimeout = conf.Defaults.ReadTimeout // Set a dynamic value
	}
	if defaults.CanUpdate(con.GracefulTimeout) { // Check if it's a zero value (recommended)
		con.GracefulTimeout = conf.Defaults.GracefulTimeout // Set a dynamic value
	}
	if defaults.CanUpdate(con.IdleTimeout) { // Check if it's a zero value (recommended)
		con.IdleTimeout = conf.Defaults.IdleTimeout // Set a dynamic value
	}
	if defaults.CanUpdate(con.Swagger) { // Check if it's a zero value (recommended)
		con.Swagger = conf.Defaults.Swagger // Set a dynamic value
	}
	if defaults.CanUpdate(con.Prometheus) { // Check if it's a zero value (recommended)
		con.Prometheus = conf.Defaults.Prometheus // Set a dynamic value
	}
	if defaults.CanUpdate(con.LocalSwagger) { // Check if it's a zero value (recommended)
		con.LocalSwagger = conf.Defaults.LocalSwagger // Set a dynamic value
	}
	if defaults.CanUpdate(con.Schema) { // Check if it's a zero value (recommended)
		con.Schema = conf.Defaults.Schema // Set a dynamic value
	}
	if defaults.CanUpdate(con.AllowedOrigins) { // Check if it's a zero value (recommended)
		con.AllowedOrigins = conf.Defaults.AllowedOrigins // Set a dynamic value
	}
	if defaults.CanUpdate(con.AllowedHeaders) { // Check if it's a zero value (recommended)
		con.AllowedHeaders = conf.Defaults.AllowedHeaders // Set a dynamic value
	}
	if defaults.CanUpdate(con.AllowedMethods) { // Check if it's a zero value (recommended)
		con.AllowedMethods = conf.Defaults.AllowedMethods // Set a dynamic value
	}
	if defaults.CanUpdate(con.IgnoreLoggingRequest) { // Check if it's a zero value (recommended)
		con.IgnoreLoggingRequest = conf.Defaults.IgnoreLoggingRequest // Set a dynamic value
	}
	if defaults.CanUpdate(con.AllowedOrigins) { // Check if it's a zero value (recommended)
		con.AllowedOrigins = conf.Defaults.AllowedOrigins // Set a dynamic value
	}
}

// Основная инициализация веб-сервера и его конфигурации
func (a *API) Initialize(ctx context.Context, conf ApiServer, version string, Trace trace.ProviderConfig) ApiServer {
	conf.Defaults.init()
	a.Router = mux.NewRouter()
	a.Config = conf.Config
	a.Config.InitializeApiServerConfig(conf)
	a.Config.init()
	a.InitializeSwagger(version)
	a.InitializePrometheus()
	a.Router.Use(a.Logging)
	a.Router.Use(a.PanicRecovery)
	a.initializeBaseRoutes()
	conf.Config = a.Config
	return conf

}

// Инициализация конфигурации Swagger
func (a *API) InitializeSwagger(version string) {
	Log.Infof("[InitializeSwagger]: Swagger is: %t", a.Config.Swagger)
	if a.Config.Swagger {
		docs.SwaggerInfo.Title = fmt.Sprintf("Swagger  %s", a.Config.App)
		docs.SwaggerInfo.Version = version
		docs.SwaggerInfo.BasePath = fmt.Sprintf("/%s", a.Config.App)
		docs.SwaggerInfo.Description = fmt.Sprintf("%s  service!", a.Config.App)
		docs.SwaggerInfo.Schemes = []string{a.Config.Schema}
		if a.Config.LocalSwagger {
			a.Config.ApiHost = fmt.Sprintf("%s:%d", a.Config.Host, a.Config.ListenPort)
		} else {
			a.Config.ApiHost = a.Config.Host
		}
		docs.SwaggerInfo.Host = a.Config.ApiHost
		uri := ""
		if a.Config.LocalSwagger {
			uri = fmt.Sprintf("%s://%s:%d/swagger/doc.json", a.Config.Schema, a.Config.Host, a.Config.ListenPort)
		} else {
			uri = fmt.Sprintf("%s://%s/direct-container-url/%s/swagger/doc.json", a.Config.Schema, a.Config.Host, a.Config.App)
		}
		Log.Infof("[InitializeSwagger]: Swagger URL: %s", uri)
		a.Router.PathPrefix("/swagger/").Handler(
			swagger.Handler(
				swagger.URL(uri),
				swagger.DeepLinking(true),
				swagger.DocExpansion("none"),
				swagger.DomID("#swagger-ui"),
			),
		)
	}
}

// Инициализация конфигурации метрик Prometheus
func (a *API) InitializePrometheus() {
	Log.Infof("[InitializePrometheus]: Prometheus is: %t", a.Config.Prometheus)
	if a.Config.Prometheus {
		instrumentation := muxprom.NewDefaultInstrumentation()
		a.Router.Use(instrumentation.Middleware)
		a.Router.HandleFunc("/prometheus", otelhttp.NewHandler(promhttp.Handler(), "Prometheus").ServeHTTP).Methods(http.MethodGet)
	}
}

// Инициализация конфигурации CORS
func (a *API) InitializeCORS(ctx context.Context) (header handlers.CORSOption, credentials handlers.CORSOption,
	methods handlers.CORSOption, origins handlers.CORSOption) {
	Log.Info("[InitializeCORS]: Header")
	header = handlers.AllowedHeaders(a.Config.AllowedHeaders)
	Log.Info("[InitializeCORS]: Credentials")
	credentials = handlers.AllowCredentials()
	Log.Info("[InitializeCORS]: Methods")
	methods = handlers.AllowedMethods(a.Config.AllowedMethods)
	allowedOrigins := []string{}
	allowedOrigins = common_lib.UpdateStingSliceFromStingSlice(ctx, allowedOrigins, a.Config.AllowedOrigins)
	allowedOrigins = common_lib.UpdateStingSlice(ctx, allowedOrigins, a.Config.ApiHost)
	Log.Info("[InitializeCORS]: Origins")
	origins = handlers.AllowedOrigins(allowedOrigins)
	return header, credentials, methods, origins
}
