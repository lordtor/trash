package go_base_api

import (
	"net/http"

	"vault-api/tools/pkg/version"

	trace "vault-api/tools/trace-lib"

	"github.com/prometheus/client_golang/prometheus/promhttp"
)

// Инициализация базовых маршрутов
func (a *API) initializeBaseRoutes() {
	Log.Info("[initializeBaseRoutes]: ...")
	a.Router.HandleFunc("/prometheus", promhttp.Handler().ServeHTTP).Methods(http.MethodGet)
	a.Router.HandleFunc("/env", a.ShowConfig()).Methods(http.MethodGet)
	a.Router.HandleFunc("/health", a.Health()).Methods(http.MethodGet)
	a.Router.HandleFunc("/info", a.ShowInfo()).Methods(http.MethodGet)

}

// ShowInfo			godoc
// @Summary			Get application version information
// @Description		Return information about the version of the application, build date, git branch, commit
// @Tags			internal
// @Accept			json
// @Produce			json
// @Success			200 {object}  JSONResult
// @Failure			500 {object} JSONResult
// @Router			/info [get]
func (a *API) ShowInfo() http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ctx, span := trace.NewSpan(r.Context(), "API.ShowInfo", nil)
		defer span.End()
		ver := version.GetVersion()
		Response(&JSONResult{Code: http.StatusOK, Data: ver}, false, w, ctx)
	}
}

// ShowConfig		godoc
// @Summary			Get a description of the environment configuration
// @Description		Returns a description of the environment configuration and parameter values, excluding passwords
// @Tags			internal
// @Accept			json
// @Produce			json
// @Success			200 {object}  JSONResult
// @Failure			500 {object} JSONResult
// @Router			/env [get]
func (a *API) ShowConfig() http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ctx, span := trace.NewSpan(r.Context(), "API.ShowConfig", nil)
		defer span.End()
		Response(&JSONResult{Code: http.StatusOK, Data: a.Config.AppConfig}, false, w, ctx)
	}
}

// Health			godoc
// @Summary			Get the health status of a web server
// @Description		Returns the health status of the web server
// @Tags			internal
// @Accept  		json
// @Produce			json
// @Success			200 {object}  JSONResult
// @Failure			500 {object} JSONResult
// @Router			/health [get]
func (a *API) Health() http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		respData := JSONResult{Code: http.StatusOK, Data: map[string]bool{"Alive": true}, Message: ""}
		a.ResponseNoTrace(&respData, w)
	}
}
