package go_base_api

import (
	"context"
	"crypto/rsa"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"strings"

	jarger "vault-api/tools/trace-lib"

	jwt "github.com/dgrijalva/jwt-go"
	"github.com/google/uuid"
	"github.com/sirupsen/logrus"
)

func GetReqIdReq(r *http.Request) string {
	return GetReqIdCtx(r.Context())
}

func GetReqIdCtx(ctx context.Context) string {
	reqId := ctx.Value(ctxReqId{}).(string)
	return reqId
}
func UseRequestId(next http.HandlerFunc) http.HandlerFunc {
	fn := func(w http.ResponseWriter, r *http.Request) {
		var reqId string
		tokenClaims, err := GetTokenClaims(r)
		if err != nil || tokenClaims.Id == "" {
			reqId = uuid.New().String()
		} else {
			reqId = tokenClaims.Id
		}
		ctx := r.Context()
		ctx = context.WithValue(ctx, ctxReqId{}, reqId)

		next.ServeHTTP(w, r.WithContext(ctx))
	}

	return fn
}
func UseLogger(next http.HandlerFunc) http.HandlerFunc {
	fn := func(w http.ResponseWriter, r *http.Request) {
		ctx := r.Context()
		var ip string
		if r.Header.Get("X-FORWARDED-FOR") != "" {
			ip = strings.Split(r.Header.Get("X-FORWARDED-FOR"), ":")[0]
		} else {
			ip = strings.Split(r.RemoteAddr, ":")[0]
		}

		if reqId := GetReqIdCtx(ctx); reqId == "" {
			// panics
			Log.Fatal("No request id associated with request")
		} else {
			log := Log.WithFields(logrus.Fields{"ip": ip, "reqId": reqId})
			ctx = context.WithValue(ctx, ctxLoggerKey{}, log)
		}

		next.ServeHTTP(w, r.WithContext(ctx))
	}

	return fn
}
func GetLogReq(r *http.Request) *logrus.Entry {
	return GetLogCtx(r.Context())
}

func GetLogCtx(ctx context.Context) *logrus.Entry {
	log := ctx.Value(ctxLoggerKey{})

	if log == nil {
		Log.Error("Logger is missing in the context") // panics
		return &logrus.Entry{Logger: Log}
	}

	return log.(*logrus.Entry)
}

// Получение содержимого токена
func GetTokenClaims(r *http.Request) (tokenClaims Claims, err error) {
	c, span := jarger.NewSpan(r.Context(), "Token.GetTokenClaims", nil)
	defer span.End()
	// l := GetLogCtx(c)

	//c := r.Context()
	data := c.Value(ctxToken{})
	userTokenRaw, err := json.Marshal(data)
	if err != nil {
		span.RecordError(err)
		span.SetStatus(1, err.Error())
		Log.WithContext(c).Error(err)
		return tokenClaims, err
	}
	err = json.Unmarshal(userTokenRaw, &tokenClaims)
	if err != nil {
		span.RecordError(err)
		span.SetStatus(1, err.Error())
		Log.WithContext(c).Error(err)
		Log.WithContext(c).Error(string(userTokenRaw))
		return tokenClaims, err
	}
	return tokenClaims, nil
}

// Валидация по открытому ключу
func ParseToken(ctx context.Context, header string, key *rsa.PublicKey) (token *jwt.Token, err error) {
	_, span := jarger.NewSpan(ctx, "Token.ParseToken", nil)
	defer span.End()
	token, err = jwt.Parse(header, func(jwtToken *jwt.Token) (interface{}, error) {
		if _, ok := jwtToken.Method.(*jwt.SigningMethodRSA); !ok {
			m := fmt.Sprintf("Unexpected method: %s", jwtToken.Header["alg"])
			err := errors.New(m)
			Log.Error(err)
			return nil, err
		}
		return key, nil
	})
	if err != nil {
		span.RecordError(err)
		span.SetStatus(1, err.Error())
		return nil, err
	}
	return token, nil
}

// Общая валидация токена и помещение его полей в контекст "decoded"
func ValidateMiddleware(h http.Handler, conf ValidateConf) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var (
			token *jwt.Token
			err   error
		)
		ctx, span := jarger.NewSpan(r.Context(), "Token.ValidateMiddleware", nil)
		defer span.End()
		l := Log.WithContext(ctx)
		key, err := jwt.ParseRSAPublicKeyFromPEM([]byte(conf.PublicKey))
		if err != nil {
			m := "Validate: parse key"
			span.RecordError(err)
			span.SetStatus(1, m)
			l.Error(err)
			Response(&JSONResult{Code: http.StatusUnauthorized, Message: m, Data: err}, false, w, ctx)
			return
		}
		authorizationHeader := r.Header.Get("Authorization")
		if authorizationHeader != "" {
			bearerToken := strings.Split(authorizationHeader, " ")
			if len(bearerToken) == 2 {
				token, err = ParseToken(ctx, bearerToken[1], key)
			} else {
				token, err = ParseToken(ctx, authorizationHeader, key)
			}
			if err != nil {
				span.RecordError(err)
				span.SetStatus(1, err.Error())
				l.Error(err)
				Response(&JSONResult{Code: http.StatusUnauthorized, Message: err.Error(), Data: err}, false, w, ctx)
				return
			}
			_, ok := token.Claims.(jwt.MapClaims)
			if !ok || !token.Valid {
				m := "token is invalid"
				err := errors.New(m)
				span.RecordError(err)
				span.SetStatus(1, m)
				l.Error(err)
				Response(&JSONResult{Code: http.StatusUnauthorized, Message: m, Data: err}, false, w, ctx)
				return
			}
			ctx = context.WithValue(ctx, ctxToken{}, token.Claims)
			if token.Valid {
				h.ServeHTTP(w, r.WithContext(ctx))
				return
			}
		} else {
			m := "an authorization header is required"
			err := errors.New(m)
			span.RecordError(err)
			span.SetStatus(1, m)
			l.Error(err)
			Response(&JSONResult{Code: http.StatusUnauthorized, Message: m, Data: err}, false, w, ctx)
			return
		}
	})
}
