package siem

import (
	"bufio"
	"encoding/json"
	"fmt"
	"net"
	"vault-api/tools/pkg/logging"
)

var (
	Log = logging.Log
)

const (
	logAliases = "[SIEM]:"
)

func Syslog(con *SiemConfig, message interface{}) (err error) {
	// if !con.Enabled {
	// 	Log.Warnf("%s siem is disable", logAliases)
	// 	return nil
	// }

	messageRaw, err := json.Marshal(message)
	if err != nil {
		Log.Errorf("%s Error Marshal messages %v", logAliases, err)
		return err
	}
	Log.Debug(messageRaw)
	url := fmt.Sprintf("%s:%d", con.Server, con.Port)
	Log.Debug("Dial")
	conn, err := net.Dial(con.Protocol, url)
	if err != nil {
		Log.Errorf("%s Error create connection %v", logAliases, err)
		return err
	}
	defer SyslogClose(conn)
	Log.Debug("Fprintf")
	n, err := fmt.Fprintf(conn, string(messageRaw))

	if err != nil {
		Log.Errorf("%s Error create messages %v", logAliases, err)
		return err
	}
	_, err = bufio.NewReader(conn).Read(messageRaw)
	if err != nil {
		Log.Errorf("%s Error send messages %v", logAliases, err)
		return err
	}
	Log.Infof("%s Send data %d to SIEM: ok", logAliases, n)
	return nil

}
func SyslogClose(conn net.Conn) {
	err := conn.Close()
	if err != nil {
		Log.Errorf("%s Error close connection %v", logAliases, err)
	}
}

type SiemConfig struct {
	Enabled  bool   `json:"enabled" yaml:"enabled"`
	Protocol string `json:"protocol" yaml:"protocol"`
	Server   string `json:"server" yaml:"server"`
	Port     int    `json:"port" yaml:"port"`
}
