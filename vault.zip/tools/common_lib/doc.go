// Package common_lib is a simple Go  module used as smaple module for most popular func.
//
// See README.md for more info.
package common_lib
