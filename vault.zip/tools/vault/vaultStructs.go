package vault

import (
	"context"
	"vault-api/tools/siem"

	api "vault-api/tools/go-base-api"

	"github.com/creasty/defaults"
	vault_api "github.com/hashicorp/vault/api"
	"github.com/sirupsen/logrus"
)

// Описание конфигурации серверов vault
type Vaults struct {
	App string
	// Соотношение идентификатора сервера vault к его конфигурации
	Sets        map[string]VaultConfig `yaml:"vault_sets"`
	DefaultRole VaultRole              `json:"default_role_setting" yaml:"default_role_setting"`
}

func (v *Vaults) Init(app string) {
	v.App = app
	v.DefaultRole.init()
	for i := range v.Sets {
		Log.Info(i)
		if entry, ok := v.Sets[i]; ok {
			if defaults.CanUpdate(entry.Role.TokenPeriod) { // Check if it's a zero value (recommended)
				entry.Role.TokenPeriod = v.DefaultRole.TokenPeriod // Set a dynamic value
			}
			if defaults.CanUpdate(entry.Role.Renewable) { // Check if it's a zero value (recommended)
				entry.Role.Renewable = v.DefaultRole.Renewable // Set a dynamic value
			}
			if defaults.CanUpdate(entry.Role.TokenExplicitMaxTtl) { // Check if it's a zero value (recommended)
				entry.Role.TokenExplicitMaxTtl = v.DefaultRole.TokenExplicitMaxTtl // Set a dynamic value
			}
			if defaults.CanUpdate(entry.Role.TokenType) { // Check if it's a zero value (recommended)
				entry.Role.TokenType = v.DefaultRole.TokenType // Set a dynamic value
			}
			// Then we reassign map entry
			entry.Role.init()
			v.Sets[i] = entry
		}

	}

}

// Описание конфигурации сервера vault
type VaultConfig struct {
	//App string `json:"-" yaml:"app"`
	// Токен авторизации
	Token    string `json:"-" yaml:"token"`
	RoleId   string `json:"role_id" yaml:"role_id"`
	SecretId string `json:"-" yaml:"secret_id"`
	// Адрес сервера
	Server string `json:"server" yaml:"server"`
	// Базовый путь к хранилищу секретов
	BasePath string `json:"base_path" yaml:"base_path"`
	// Описания пользователя
	User VaultUser `json:"user,omitempty" yaml:"user"`
	// Описания конфигурации роли
	Role VaultRole `json:"role" yaml:"role"`
}

// Описания пользователя
type VaultUser struct {
	// список доменных групп пользователя
	GroupeNames []string `json:"grope_names" yaml:"grope_names"`
	// ФИО пользователя
	UserName string `json:"user_name" yaml:"user_name"`
	// Email пользователя
	Email string `json:"email" yaml:"email"`
	// IP-адрес пользователя
	IP string `json:"ip" yaml:"ip"`
}

// Описания конфигурации роли
type VaultRole struct {
	// Имя роли
	RoleNme string `default:"-" json:"role_name" yaml:"role_name"`
	// Разрешенные политики
	AllowedPolicies []string `default:"[\"default\", \"internal_lookup_revoke\", \"internal_root_list\"]" json:"allowed_policies" yaml:"allowed_policies"`
	// Срок жизни токена
	TokenPeriod int `default:"28800" json:"token_period" yaml:"token_period"`
	// Признак отвечающий за возобновляемость токена
	Renewable bool `default:"false" json:"renewable" yaml:"renewable"`
	// Максимальный срок жизни
	TokenExplicitMaxTtl int `default:"14400" json:"token_explicit_max_ttl" yaml:"token_explicit_max_ttl"`
	// Тип токена
	TokenType string `default:"service" json:"token_type" yaml:"token_type"`
	// Префикс
	PathSuffix string `default:"-" json:"path_suffix" yaml:"path_suffix"`
	// Разрешенные псевдонимы
	AllowedEntityAliases string `default:"-" json:"allowed_entity_aliases" yaml:"allowed_entity_aliases"`
}

// Инициализация роли (значения по умолчанию)
func (vr *VaultRole) init() {

	err := defaults.Set(vr)
	if err != nil {
		Log.Error(err)
	}
}

// func (vr VaultRole) Defaults(dvr VaultRole) {
// 	if defaults.CanUpdate(vr.TokenPeriod) { // Check if it's a zero value (recommended)
// 		vr.TokenPeriod = dvr.TokenPeriod // Set a dynamic value
// 	}
// 	if defaults.CanUpdate(vr.Renewable) { // Check if it's a zero value (recommended)
// 		vr.Renewable = dvr.Renewable // Set a dynamic value
// 	}
// 	if defaults.CanUpdate(vr.TokenExplicitMaxTtl) { // Check if it's a zero value (recommended)
// 		vr.TokenExplicitMaxTtl = dvr.TokenExplicitMaxTtl // Set a dynamic value
// 	}
// 	if defaults.CanUpdate(vr.TokenType) { // Check if it's a zero value (recommended)
// 		vr.TokenType = dvr.TokenType // Set a dynamic value
// 	}
// 	vr.init()
// }

// Описание клиента vault сервера
type Vault struct {
	// Указатель на клиента
	Client *vault_api.Client
	// Указатель на конфигурацию сервера vault
	Conf *VaultConfig

	Siem siem.SiemConfig
	// Контекст клиента
	ctx context.Context
}
type SiemLog struct {
	VaultId  string
	RoleID   string
	UserName string
	Email    string
	IP       string
}

// Структура vault-api
type API struct {
	//  Имя доменной группы
	App string `json:"app,omitempty" yaml:"app"`
	// Общая конфигурация сервиса vault
	Conf *Vaults
	Siem siem.SiemConfig
	T    api.ValidateConf
	Log  *logrus.Entry
}

// Структура списки групп
type GroupList struct {
	// Списки групп
	Groups []string `json:"groups"`
}
