package vault

import (
	"net/http"
	api "vault-api/tools/go-base-api"

	"github.com/gorilla/mux"
	"go.opentelemetry.io/contrib/instrumentation/github.com/gorilla/mux/otelmux"
)

// Маршруты для vault-api
func (a *API) Routes() *mux.Router {
	r := mux.NewRouter()
	r.Use(otelmux.Middleware(a.App))
	apiSubRouter := r.PathPrefix("/api/").Subrouter()
	vaultSubRoute := apiSubRouter.PathPrefix("/v1").Subrouter()
	vaultSubRoute.Path("/getAppRoles").Handler(api.ValidateMiddleware(a.getAppRoles(), a.T)).Queries("vault", "{vault}").Methods(http.MethodGet)
	vaultSubRoute.Path("/getValidRolesForUser").Handler(api.ValidateMiddleware(a.getValidRolesForUser(), a.T)).Queries("vault", "{vault}").Methods(http.MethodGet)
	vaultSubRoute.Path("/getAppRoleToken").Handler(api.ValidateMiddleware(a.getAppRoleToken(), a.T)).Queries("vault", "{vault}").Methods(http.MethodPut)
	vaultSubRoute.Path("/getVaults").Handler(api.ValidateMiddleware(a.getVaults(), a.T)).Methods(http.MethodGet)
	vaultSubRoute.Path("/getSecretNameList").Handler(api.ValidateMiddleware(a.getSecretNameList(), a.T)).Queries("vault", "{vault}", "team", "{team}", "env", "{env}", "app", "{app}").Methods(http.MethodGet)
	return r
}
