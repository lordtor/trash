# vault-api

Confluence:

* [Интеграция с Vault](https://confluence.homecredit.ru/confluence/pages/viewpage.action?pageId=158876751)

* [Формат взаимодействия между vault-api и DevOps portal UI](https://confluence.homecredit.ru/confluence/pages/viewpage.action?pageId=185375090)

## Swagger

Download swag by using:

```Bash
go install github.com/swaggo/swag/cmd/swag@latest
```

Documentation update:

```Bash
swag init  --parseDependency --generatedTime --parseInternal  --parseDepth 2
```

## Convert Swagger documentation to Insomnia Collection

Import file collection ```vault-api\docs\swagger.json```

## ENV variables

1. OMNI_GLOBAL_SPRING_CLOUD_CONFIG_URI - config server url

    ``` Bash
    export OMNI_GLOBAL_SPRING_CLOUD_CONFIG_URI=http://omni***:omni***@devops-portal.k8s-test.homecredit.ru/direct-container-url/config-server/
    ```

    or

    ``` PowerShell
    $env:OMNI_GLOBAL_SPRING_CLOUD_CONFIG_URI="http://omni***:omni***@devops-portal.k8s-test.homecredit.ru/direct-container-url/config-server/"
    ```

2. APP_NAME - set different service name

    ``` Bash
    export APP_NAME=Service_Name
    ```

    or

    ``` PowerShell
    $env:APP_NAME="Service_Name"
    ```

3. PROFILE_NAME - set different profile

    ``` Bash
    export PROFILE_NAME=dev
    ```

    or

    ``` PowerShell
    $env:PROFILE_NAME="develop"
    ```

    * "develop" - for use only local config file `application-develop.yml`
    * other for use different file from config server ex.: `application-dev.yml`

4. KUBERNETES_NODE_IP - Jaeger agent host

    ``` Bash
    export KUBERNETES_NODE_IP=OS-5962.homecredit.ru
    ```

    or

    ``` PowerShell
    $env:KUBERNETES_NODE_IP="OS-5962.homecredit.ru"
    ```

5. OMNI_GLOBAL_ENVIRONMENT_NAME - Enviroment name for jaeger trace

    ``` Bash
    export OMNI_GLOBAL_ENVIRONMENT_NAME=develop
    ```

    or

    ``` PowerShell
    $env:OMNI_GLOBAL_ENVIRONMENT_NAME="develop"
    ```

### Local configuration (Use for config server)

For example `application-develop.yml`

## Password files

* Windows:
  * `__debug_bin.exe.json` - Use by debugger vscode
  * `main.exe.json` - Use by go run main.go
  * `vault-api.exe.json` - Use for normal work
* Linux:
  * `__debug_bin.json` - Use by debugger vscode
  * `main.json` - Use by go run main.go
  * `vault-api.json` - Use for normal work

## Linter checks

1. Install linter

    ```Bash
    go install github.com/golangci/golangci-lint/cmd/golangci-lint
    ```

2. Run check

    ``` Bash
    ../../bin/golangci-lint run  --out-format checkstyle > checkstyle.xml
    ```

## Tests & Coverage

1. Run test

    ``` Bash
    go test -v -coverpkg=./... -coverprofile=profile.cov ./... -json > test_report.json
    ```

2. Coverage

    ```Bash
    go tool cover -func profile.cov
    ```
