<#
.SYNOPSIS
	Update documentation.
.DESCRIPTION
	Update Swagger documentation.
.EXAMPLE
	PS> ./run
.LINK
	none
.NOTES
	Author: Yuriy Rumyantsev
#>

swag init  --parseDependency --generatedTime --parseInternal  --parseDepth 2