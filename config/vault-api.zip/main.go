// swagger:meta
// @termsOfService https://confluence.homecredit.ru/confluence/pages/viewpage.action?pageId=157493603

// @contact.name API Support
// @contact.url https://jira.homecredit.ru/projects/DEVOPS
// @contact.email yrumyantsev@homecredit.ru

// @license.name Apache 2.0
// @license.url http://www.apache.org/licenses/LICENSE-2.0.html

// @securityDefinitions.apikey ApiKeyAuth
// @in header
// @name Authorization

package main

import (
	"context"
	"fmt"

	ex "vault-api/internal/extend_config"
	vault "vault-api/tools/vault"

	api "vault-api/tools/go-base-api"

	"vault-api/tools/base_config"
	"vault-api/tools/pkg/logging"
	version "vault-api/tools/pkg/version"
	trace "vault-api/tools/trace-lib"
)

var (
	Log  = logging.Log
	Conf = ex.C{}
	// Bootstrap local & bin version.
	binVersion      = "0.1.2"
	aBuildNumber    = "00000"
	aBuildTimeStamp = ""
	aGitBranch      = "master"
	aGitHash        = ""
)

func init() {
	logging.InitLog("")
	version.InitVersion(binVersion, aBuildNumber, aBuildTimeStamp, aGitBranch, aGitHash)
	Conf.ReloadConfig()
	Conf.API.Config.App = Conf.AppName
	// Bootstrap Trace.
	Conf.Trace.Environment = Conf.ProfileName
	Conf.Trace.ServiceName = Conf.AppName
	Conf.Trace.ServiceVersion = version.AppVersion.Version
	if Conf.Trace.JaegerHost == "" {
		Conf.Trace.JaegerHost = base_config.GetValueByNameFromEnv("KUBERNETES_NODE_IP")
	}
	if env := base_config.GetValueByNameFromEnv("OMNI_GLOBAL_ENVIRONMENT_NAME"); env != "" {
		Conf.Trace.Environment = env
	}
	logging.ChangeLogLevel(Conf.LogLevel)

}

func main() {

	ctx := context.Background()
	// Bootstrap tracer.
	Log.Info(Conf.Trace)
	prv, err := trace.NewProvider(Conf.Trace)
	if err != nil {
		Log.Fatalln(err)
	}
	defer prv.Close(ctx)
	Conf.Vaults.Init(Conf.AppName)

	// Bootstrap vault.
	//remedyAPI := remedy.API{App: Conf.AppName, Conf: &Conf.Remedy, T: Conf.Token}

	vaultAPI := vault.API{App: Conf.AppName, Conf: &Conf.Vaults, Siem: Conf.Siem, T: Conf.Token}
	// Bootstrap api.
	a := api.API{}
	// apiConf :=
	Conf.API = a.Initialize(ctx, Conf.API, version.GetVersion().Version, Conf.Trace)
	a.Config.ApiServerConfigUpdate(ctx, a.Config, Conf)
	Log.Info(a.Config.AppConfig)

	// Mount vault routes
	a.Mount(ctx, fmt.Sprintf("/%s/vault/", Conf.AppName), vaultAPI.Routes())
	a.Run(ctx)
}
