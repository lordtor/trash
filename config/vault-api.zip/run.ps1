<#
.SYNOPSIS
	Run project in develop mode
.DESCRIPTION
	This PowerShell script run main.go file use develop enviroment.
.EXAMPLE
	PS> ./run
.LINK
	none
.NOTES
	Author: Yuriy Rumyantsev
#>

$env:PROFILE_NAME="develop"
go run main.go