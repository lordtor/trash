package go_base_api

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"net/http"
	"os"
	"os/signal"
	"strings"
	"time"

	common_lib "vault-api/tools/common_lib"
	"vault-api/tools/pkg/logging"
	"vault-api/tools/token"
	jarger "vault-api/tools/trace-lib"

	"github.com/gorilla/handlers"
	"github.com/pkg/errors"
	"go.opentelemetry.io/otel/attribute"
	t "go.opentelemetry.io/otel/trace"
)

var (
	DefaultCT = []string{"Content-Type", "application/json"}
	Log       = logging.Log
)

func handleErrorSpan(span t.Span, err error, method string) error {
	err = errors.Wrapf(err, method)
	span.RecordError(err)
	span.SetStatus(1, err.Error())
	return err
}

func handleError(err error, method string) error {
	err = errors.Wrapf(err, method)
	return err
}

// Запуск веи-сервера
func (a *API) Run(ctx context.Context) {
	var wait time.Duration
	flag.DurationVar(&wait, "graceful-timeout", time.Second*time.Duration(a.Config.GracefulTimeout), "the duration for which the server gracefully wait for existing connections to finish - e.g. 15s or 1m")
	flag.Parse()
	header, credentials, methods, origins := a.InitializeCORS(ctx)
	srv := &http.Server{
		Handler:      handlers.CORS(header, credentials, methods, origins)(a.Router),
		Addr:         fmt.Sprintf(":%d", a.Config.ListenPort),
		WriteTimeout: time.Duration(a.Config.WriteTimeout) * time.Second,
		ReadTimeout:  time.Duration(a.Config.ReadTimeout) * time.Second,
		IdleTimeout:  time.Second * time.Duration(a.Config.IdleTimeout),
	}
	go func() {
		if err := srv.ListenAndServe(); err != nil {
			Log.Errorf("[Run]: %v", handleError(err, "ListenAndServe"))
		}
	}()

	c := make(chan os.Signal, 1)
	// We'll accept graceful shutdowns when quit via SIGINT (Ctrl+C)
	// SIGKILL, SIGQUIT or SIGTERM (Ctrl+/) will not be caught.
	signal.Notify(c, os.Interrupt)
	// Block until we receive our signal.
	<-c
	// Create a deadline to wait for.
	ctx, cancel := context.WithTimeout(context.Background(), wait)
	defer cancel()
	// Doesn't block if no connections, but will otherwise wait
	// until the timeout deadline.
	err := srv.Shutdown(ctx)
	if err != nil {
		Log.Error(handleError(err, "Shutdown"))
	}
	// Optionally, you could run srv.Shutdown in a goroutine and block on
	// <-ctx.Done() if your application should wait for other services
	// to finalize based on context cancellation.
	Log.Info("shutting down")
	os.Exit(0)
}

// Подключение дополнительных методов к роутеру
func (a *API) Mount(ctx context.Context, path string, handler http.Handler) {
	a.Router.PathPrefix(path).Handler(
		http.StripPrefix(strings.TrimSuffix(path, "/"), handler),
	)
}

// Логирование запросов к веб-серверу
func (a *API) Logging(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		start := time.Now()
		next.ServeHTTP(w, req)
		if !common_lib.SliceContain(a.Config.IgnoreLoggingRequest, req.RequestURI) {
			Log.Debugf("%s %s %s", req.Method, req.RequestURI, time.Since(start))
		} else {
			Log.Tracef("%s %s %s", req.Method, req.RequestURI, time.Since(start))
		}
	})
}

// Обработка ошибок от веб-сервера
func (a *API) PanicRecovery(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		defer func() {
			if err := recover(); err != nil {
				Log.Error(err)
				http.Error(w, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
			}
		}()
		next.ServeHTTP(w, req)
	})
}

// Формирование и возврат ответа без трассировки
func (a *API) ResponseNoTrace(data *JSONResult, w http.ResponseWriter) {
	w.Header().Set(DefaultCT[0], DefaultCT[1])
	resp, err := json.Marshal(data)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	w.WriteHeader(data.Code)
	intE, err := w.Write(resp)
	if err != nil {
		http.Error(w, err.Error(), intE)
		return
	}
}

// // Формирование и возврат ответа
// func Response(data *JSONResult, responseData bool, w http.ResponseWriter, ctx context.Context) {
// 	_, span := trace.NewSpan(ctx, "Response", nil)
// 	defer span.End()
// 	w.Header().Set(DefaultCT[0], DefaultCT[1])
// 	var field interface{}
// 	if responseData {
// 		field = data.Data
// 	} else {
// 		field = data
// 	}
// 	resp, err := json.Marshal(field)
// 	if err != nil {
// 		Log.Errorf("[Response]: %v", handleErrorSpan(span, err, "Marshal"))
// 		w.WriteHeader(http.StatusInternalServerError)
// 		span.End()
// 		return
// 	}
// 	_, err = w.Write(resp)
// 	if err != nil {
// 		Log.Errorf("[Response]: %v", handleErrorSpan(span, err, "Write"))
// 		w.WriteHeader(http.StatusInternalServerError)
// 		span.End()
// 		return
// 	}
// 	w.WriteHeader(data.Code)
// 	span.SetAttributes(attribute.Key("Code").Int(data.Code))
// 	span.SetAttributes(attribute.Key("Message").String(data.Message))
// 	if data.Code < 400 {
// 		span.SetStatus(2, data.Message)
// 	} else {
// 		w.WriteHeader(data.Code)
// 		span.SetStatus(1, data.Message)
// 	}
// 	span.End()
// }

// Формирование и возврат ответа
func Response(data *JSONResult, responseData bool, w http.ResponseWriter, ctx context.Context) {
	c, span := jarger.NewSpan(ctx, "Response", nil)
	defer span.End()
	l := token.GetLogCtx(c)
	w.Header().Set(DefaultCT[0], DefaultCT[1])
	var field interface{}
	if responseData {
		field = data.Data
	} else {
		field = data
	}
	resp, err := json.Marshal(field)
	if err != nil {
		msg := "Failed to convert data"
		l.WithError(err).Error(msg)
		span.RecordError(err)
		span.SetStatus(1, msg)
		http.Error(w, err.Error(), http.StatusInternalServerError)
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	w.WriteHeader(data.Code)
	span.SetAttributes(attribute.Key("reqId").String(GetReqIdCtx(ctx)))
	span.SetAttributes(attribute.Key("Code").Int(data.Code))
	span.SetAttributes(attribute.Key("Message").String(data.Message))
	intE, err := w.Write(resp)
	if err != nil {
		msg := "Failed to write response"
		l.WithError(err).Error(msg)
		span.RecordError(err)
		span.SetStatus(1, msg)
		http.Error(w, err.Error(), intE)
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	span.SetStatus(2, data.Message)

}
