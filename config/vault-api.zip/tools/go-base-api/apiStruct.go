package go_base_api

import (
	"github.com/creasty/defaults"
	"github.com/gorilla/mux"
)

// Описание структуры веб-сервера
type API struct {
	// Ссылка на роутер
	Router *mux.Router
	// Конфигурация веб-сервера
	Config ApiServerConfig
}

// Описание данных ответа
type JSONResult struct {
	// Код возвращаемого ответа
	Code int `json:"code" `
	// Сообщение
	Message string `json:"message,omitempty"`
	// Возвращаемый ответ
	Data interface{} `json:"data,omitempty"`
	// Закладка на запрос к CouchDB
	Bookmark string `json:"bookmark,omitempty"`
}

type ApiServer struct {
	Config   ApiServerConfig `json:"conf" yaml:"conf"`
	Defaults ApiServerConfig `json:"default_api_setting" yaml:"default_api_setting"`
}

// Описание конфигурации API сервера
type ApiServerConfig struct {
	// Порт сервера
	ListenPort int `json:"listen_port" yaml:"listen_port" default:"8080"`
	// Таймаут на запись
	WriteTimeout int `json:"write_timeout" yaml:"write_timeout" default:"30"`
	// Таймаут на чтение
	ReadTimeout int `json:"read_timeout" yaml:"read_timeout" default:"30"`
	// Таймаут на запуск
	GracefulTimeout int `json:"graceful_timeout" yaml:"graceful_timeout" default:"15"`
	// Таймаут на корректное завершение
	IdleTimeout int `json:"idle_timeout" yaml:"idle_timeout" default:"60"`
	// Включить Swagger
	Swagger bool `json:"swagger" yaml:"swagger" default:"false"`
	// Включить метрики Prometheus
	Prometheus bool `json:"prometheus" yaml:"prometheus" default:"false"`
	// Локальный Swagger
	LocalSwagger bool `json:"local_swagger" yaml:"local_swagger" default:"false"`
	// Схема работы сервера
	Schema string `json:"schema" yaml:"schema" default:"http"`
	// Имя сервиса
	App string `json:"app" yaml:"app" default:"-"`
	// Хост сервиса
	Host string `json:"host" yaml:"host" default:"-"`
	// Хост сервиса для Swagger (Base URL)
	ApiHost string `json:"api_host" yaml:"api_host" default:"-"`
	// CORS: Доверенные узлы
	AllowedOrigins []string `json:"allowed_origins" yaml:"allowed_origins" default:"[\"*\"]"`
	// CORS: Доверенные заголовки
	AllowedHeaders []string `json:"allowed_header" yaml:"allowed_header" default:"[\"X-Requested-With\", \"Content-Type\", \"Authorization\", \"SERVICE-AGENT\", \"Access-Control-Allow-Methods\", \"Date\", \"X-FORWARDED-FOR\", \"Accept\", \"Content-Length\", \"Accept-Encoding\", \"Service-Agent\"]"`
	// CORS: Доверенные методы
	AllowedMethods []string `json:"allowed_methods" yaml:"allowed_methods" default:"[\"GET\", \"POST\", \"PUT\", \"PATCH\", \"HEAD\", \"OPTIONS\"]"`
	// Вся конфигурация итогового сервиса
	AppConfig interface{} `json:"-" yaml:"-"  default:"-"`
	// Список методов исключенных из логирования веб-сервера
	IgnoreLoggingRequest []string `json:"ignore_logging_request" yaml:"ignore_logging_request" default:"[\"/prometheus\", \"/health\"]"`
}

func (a *ApiServerConfig) init() {

	err := defaults.Set(a)
	if err != nil {
		Log.Error(err)
	}
}
