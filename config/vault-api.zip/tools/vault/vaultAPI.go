package vault

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"strings"
	"vault-api/tools/common_lib"
	api "vault-api/tools/go-base-api"
	"vault-api/tools/siem"
	"vault-api/tools/token"
	jarger "vault-api/tools/trace-lib"

	muxContext "github.com/gorilla/context"
	"go.opentelemetry.io/otel/attribute"
)

var (
	DefaultCT = []string{"Content-Type", "application/json"}
)

// Генерация персонального токена
func (a *API) GetSingleToken(ctx context.Context, role string, vaultId string, siem siem.SiemConfig) (string, error) {
	ctx, span := jarger.NewSpan(ctx, "API.GetSingleToken", nil)
	defer span.End()
	span.SetAttributes(attribute.Key("RequestedRole").String(role))
	Log.Trace(role)
	span.SetAttributes(attribute.Key("VaultId").String(vaultId))
	Log.Trace(vaultId)
	c := a.Conf.Sets[vaultId]
	Log.Trace(c)
	ctx, v, err := NewVault(ctx, &c, siem)
	if err != nil {
		Log.Error(err.Error())
		span.RecordError(err)
		span.SetStatus(1, err.Error())
		return "", err
	}
	Log.Debug("SetAppRole")
	_, err = v.SetAppRole(ctx, role)
	if err != nil {
		Log.Error(err.Error())
		span.RecordError(err)
		span.SetStatus(1, err.Error())
		return "", err
	}
	Log.Debug("GetAppRoleId")
	appRoleId, err := v.GetAppRoleId(ctx, role)
	if err != nil {
		Log.Error(err.Error())
		span.RecordError(err)
		span.SetStatus(1, err.Error())
		return "", err
	}
	span.SetAttributes(attribute.Key("RoleID").String(appRoleId))
	Log.Debug("GetAppRoleSecretId")
	appRoleSecretId, err := v.GetAppRoleSecretId(ctx, role, appRoleId)
	if err != nil {
		Log.Error(err.Error())
		span.RecordError(err)
		span.SetStatus(1, err.Error())
		return "", err
	}
	Log.Debug("GetAppRoleToken")
	Token, err := v.GetAppRoleToken(ctx, appRoleId, appRoleSecretId)
	if err != nil {
		Log.Error(err.Error())
		span.RecordError(err)
		span.SetStatus(1, err.Error())
		return "", err
	}
	Log.Trace(Token)
	return Token, nil
}

// Проверка идентификатора сервера vault
func (a *API) CheckVaultID(ctx context.Context, id string) error {
	_, span := jarger.NewSpan(ctx, "API.CheckVaultID", nil)
	defer span.End()
	if _, ok := a.Conf.Sets[id]; ok {
		return nil
	} else {
		return errors.New("error vault id not exist")
	}
}

// Модификация параметров роли
func (a *API) SetUserRole(ctx context.Context, r *http.Request) (err error) {
	ctx, span := jarger.NewSpan(ctx, "API.SetUserRole", nil)
	defer span.End()
	var (
		token = token.Claims{}
	)
	vaultId := r.FormValue("vault")
	err = a.CheckVaultID(ctx, vaultId)
	if err != nil {
		Log.Error(err)
		span.RecordError(err)
		span.SetStatus(1, err.Error())
		return err
	}
	err = common_lib.DecodeInterfaceToInterface(ctx, muxContext.Get(r, "decoded"), &token)
	if err != nil {
		err = errors.New("error decode user token")
		Log.Error(err)
	}
	con := a.Conf.Sets[vaultId]
	con.User.UserName = token.Login
	con.User.Email = token.Email
	con.User.GroupeNames = token.Authorities

	con.User.UserName = token.Login
	con.User.Email = token.Email
	con.User.GroupeNames = token.Authorities
	if r.Header.Get("X-FORWARDED-FOR") != "" {
		con.User.IP = strings.Split(r.Header.Get("X-FORWARDED-FOR"), ":")[0]
	} else {
		con.User.IP = strings.Split(r.RemoteAddr, ":")[0]
	}
	//con.Role.init()
	a.Conf.Sets[vaultId] = con

	if a.Conf.Sets[vaultId].User.UserName == "" {
		err = errors.New("user name not set")
		Log.Error(err)

	}
	if a.Conf.Sets[vaultId].User.Email == "" {
		err = errors.New("user email not set")
		Log.Error(err)
	}
	if a.Conf.Sets[vaultId].User.IP == "" {
		err = errors.New("user IP not set")
		Log.Error(err)
	}
	if len(a.Conf.Sets[vaultId].User.GroupeNames) <= 0 {
		err = errors.New("user group not set")
		Log.Error(err.Error())
	}
	if err != nil {
		span.RecordError(err)
		span.SetStatus(1, err.Error())
		return err
	}
	return err

}

// getAppRoleToken	godoc
// @Summary			Generate user vault token select group
// @Tags			vault
// @Description		Method generate user vault token for valid vault approles by selected groups
// @Accept			json
// @Produce			json
// @Success			200 {object} api.JSONResult{data=map[string]string}
// @Failure			500,401,422 {object } api.JSONResult
// @Param			vault query string true "VaultID"
// @Param			groups body GroupList true "Groups name for generate token"
// @Router			/vault/api/v1/getAppRoleToken [put]
// @Security		ApiKeyAuth
func (a *API) getAppRoleToken() http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ctx, span := jarger.NewSpan(r.Context(), "API.GetAppRoleToken", nil)
		defer span.End()
		var (
			tokens    = map[string]string{}
			groupList = GroupList{}
		)
		vaultId := r.FormValue("vault")
		Log.Debug("CheckVaultID")
		err := a.CheckVaultID(ctx, vaultId, *a.Conf)
		if err != nil {
			Log.Error(err)
			span.RecordError(err)
			span.SetStatus(1, err.Error())
			api.Response(&api.JSONResult{Code: http.StatusUnprocessableEntity, Data: err}, false, w, ctx)
			return
		}
		span.SetAttributes(attribute.Key("VaultId").String(vaultId))
		Log.Debug("SetUserRole")
		err = a.SetUserRole(ctx, r, *a.Conf)
		if err != nil {
			err := errors.New("error: Set user and role")
			Log.Error(err)
			span.RecordError(err)
			span.SetStatus(1, err.Error())
			api.Response(&api.JSONResult{Code: http.StatusInternalServerError, Data: err}, false, w, ctx)
			return
		}
		err = json.NewDecoder(r.Body).Decode(&groupList)
		if err != nil {
			Log.Error(err.Error())
			span.RecordError(err)
			span.SetStatus(1, err.Error())
			api.Response(&api.JSONResult{Code: http.StatusInternalServerError, Data: err}, false, w, ctx)
			return
		}
		if len(groupList.Groups) < 1 {
			err := errors.New("user group not set")
			Log.Error(err.Error())
			span.RecordError(err)
			span.SetStatus(1, err.Error())
			api.Response(&api.JSONResult{Code: http.StatusInternalServerError, Data: err}, false, w, ctx)
			return
		}
		span.SetAttributes(attribute.Key("GroupList").StringSlice(groupList.Groups))
		for id := range groupList.Groups {
			Log.Debug("GetSingleToken")
			t, err := a.GetSingleToken(ctx, groupList.Groups[id], vaultId, a.Siem)
			if err != nil {
				err := errors.New("error: Get single token")
				Log.Error(err)
				span.RecordError(err)
				span.SetStatus(1, err.Error())
				api.Response(&api.JSONResult{Code: http.StatusInternalServerError, Data: err}, false, w, ctx)
				return
			}
			tokens[groupList.Groups[id]] = t
		}
		api.Response(&api.JSONResult{Code: http.StatusOK, Data: tokens, Message: ""}, false, w, ctx)
	}
}

// getValidRolesForUser godoc
// @Summary			Get user approles
// @Tags			vault
// @Description		Method response all valid vault approles for selected vault server
// @Accept			json
// @Produce			json
// @Success			200 {object} api.JSONResult{data=[]string}
// @Failure			500,401,422 {object } api.JSONResult
// @Param			vault query string true "VaultID"
// @Router			/vault/api/v1/getValidRolesForUser [get]
// @Security		ApiKeyAuth
func (a *API) getValidRolesForUser() http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ctx, span := jarger.NewSpan(r.Context(), "API.GetValidRolesForUser", nil)
		defer span.End()
		vaultId := r.FormValue("vault")
		err := a.CheckVaultID(ctx, vaultId)
		if err != nil {
			Log.Error(err)
			span.RecordError(err)
			span.SetStatus(1, err.Error())
			api.Response(&api.JSONResult{Code: http.StatusUnprocessableEntity, Data: err}, false, w, ctx)
			return
		}
		span.SetAttributes(attribute.Key("VaultId").String(vaultId))
		err = a.SetUserRole(ctx, r)
		if err != nil {
			err := errors.New("error: Set user and role")
			Log.Error(err)
			span.RecordError(err)
			span.SetStatus(1, err.Error())
			api.Response(&api.JSONResult{Code: http.StatusInternalServerError, Data: err}, false, w, ctx)
			return
		}
		c := a.Conf.Sets[vaultId]
		ctx, v, err := NewVault(ctx, &c, siem.SiemConfig{})
		if err != nil {
			Log.Error(err.Error())
			span.RecordError(err)
			span.SetStatus(1, err.Error())
			api.Response(&api.JSONResult{Code: http.StatusInternalServerError, Data: err}, false, w, ctx)
			return
		}
		validRoles, err := v.GetValidRolesForUser(ctx)
		if err != nil {
			Log.Error(err)
			span.RecordError(err)
			span.SetStatus(1, err.Error())
			api.Response(&api.JSONResult{Code: http.StatusInternalServerError, Data: err}, false, w, ctx)
			return
		}
		api.Response(&api.JSONResult{Code: http.StatusOK, Data: validRoles, Message: ""}, false, w, ctx)
	}
}

// getAppRoles		godoc
// @Summary			Get Vault AppRoles
// @Tags			vault
// @Description		Method response all existing vault approles for selected vault server
// @Accept			json
// @Produce			json
// @Success			200 {object} api.JSONResult{data=[]string}
// @Failure			500,401,422 {object } api.JSONResult
// @Param			vault query string true "VaultID"
// @Router			/vault/api/v1/getAppRoles [get]
// @Security		ApiKeyAuth
func (a *API) getAppRoles() http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ctx, span := jarger.NewSpan(r.Context(), "API.GetAppRoles", nil)
		defer span.End()
		vaultId := r.FormValue("vault")
		err := a.CheckVaultID(ctx, vaultId)
		if err != nil {
			Log.Error(err)
			span.RecordError(err)
			span.SetStatus(1, err.Error())
			api.Response(&api.JSONResult{Code: http.StatusUnprocessableEntity, Data: err}, false, w, ctx)
			return
		}
		span.SetAttributes(attribute.Key("VaultId").String(vaultId))
		con := a.Conf.Sets[vaultId]
		ctx, v, err := NewVault(ctx, &con, siem.SiemConfig{})
		if err != nil {
			Log.Error(err.Error())
			span.RecordError(err)
			span.SetStatus(1, err.Error())
			api.Response(&api.JSONResult{Code: http.StatusInternalServerError, Data: err}, false, w, ctx)
			return
		}
		appRoles, err := v.GetAppRoles(ctx)
		if err != nil {
			Log.Error(err.Error())
			span.RecordError(err)
			span.SetStatus(1, err.Error())
			api.Response(&api.JSONResult{Code: http.StatusInternalServerError, Data: err}, false, w, ctx)
			return
		}
		span.SetAttributes(attribute.Key("AppRoles").StringSlice(appRoles))
		api.Response(&api.JSONResult{Code: http.StatusOK, Data: appRoles, Message: ""}, false, w, ctx)
	}
}

// getSecretNameList godoc
// @Summary			Get Vault Secret Names List
// @Tags			vault
// @Description		Method response all secret names end app for selected vault server, team, env, app
// @Accept			json
// @Produce			json
// @Success			200 {object} api.JSONResult{data=[]string}
// @Failure			500,401,422 {object} api.JSONResult
// @Param			vault query string true "VaultID"
// @Param			cluster query string true "ClusterID"
// @Param			team query string true "Team"
// @Param			env query string true "Env"
// @Param			app query string true "App"
// @Router			/vault/api/v1/getSecretNameList [get]
// @Security		ApiKeyAuth
func (a *API) getSecretNameList() http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ctx, span := jarger.NewSpan(r.Context(), "API.GetSecretNameList", nil)
		defer span.End()
		var con VaultConfig
		vaultId := r.FormValue("vault")
		clusterId := r.FormValue("cluster")
		teamId := r.FormValue("team")
		envId := r.FormValue("env")
		appId := r.FormValue("app")
		err := a.CheckVaultID(ctx, vaultId)
		if err != nil {
			Log.Error(err)
			span.RecordError(err)
			span.SetStatus(1, err.Error())
			api.Response(&api.JSONResult{Code: http.StatusUnprocessableEntity, Data: err}, false, w, ctx)
			return
		}
		con = a.Conf.Sets[vaultId]
		ctx, v, err := NewVault(ctx, &con, siem.SiemConfig{})
		if err != nil {
			Log.Error(err.Error())
			span.RecordError(err)
			span.SetStatus(1, err.Error())
			api.Response(&api.JSONResult{Code: http.StatusInternalServerError, Data: con, Message: err.Error()}, false, w, ctx)
			return
		}
		listSecrets, err := v.GetListSecrets(ctx, clusterId, teamId, envId, appId)
		Log.Debug(listSecrets)
		Log.Debug(err)
		if err != nil {
			Log.Error(err)
			span.RecordError(err)
			span.SetStatus(1, err.Error())
			api.Response(&api.JSONResult{Code: http.StatusInternalServerError, Data: err}, false, w, ctx)
			return
		}
		span.SetAttributes(attribute.Key("ListSecrets").StringSlice(listSecrets))
		api.Response(&api.JSONResult{Code: http.StatusOK, Data: listSecrets, Message: ""}, false, w, ctx)
	}
}

// getVaults		godoc
// @Summary			Get Vaults
// @Tags			vault
// @Description		Method response all existing vaults servers
// @Accept			json
// @Produce			json
// @Success			200 {object} api.JSONResult{data=map[string]string}
// @Failure			500,401 {object } api.JSONResult
// @Router			/vault/api/v1/getVaults [get]
// @Security		ApiKeyAuth
func (a *API) getVaults() http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		vaults := map[string]string{}
		ctx, span := jarger.NewSpan(r.Context(), "API.GetVaults", nil)
		defer span.End()
		for i, d := range a.Conf.Sets {
			vaults[i] = d.Server
		}
		api.Response(&api.JSONResult{Code: http.StatusOK, Data: vaults, Message: ""}, false, w, ctx)
	}
}
