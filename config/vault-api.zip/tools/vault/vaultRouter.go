package vault

import (
	"context"
	"encoding/json"
	"net/http"
	api "vault-api/tools/go-base-api"
	"vault-api/tools/token"
	jarger "vault-api/tools/trace-lib"

	"github.com/gorilla/mux"
	"go.opentelemetry.io/contrib/instrumentation/github.com/gorilla/mux/otelmux"
	"go.opentelemetry.io/otel/attribute"
)

// Маршруты для vault-api
func (a *API) Routes() *mux.Router {
	//a.Conf = &conf
	//a.Siem = siem
	r := mux.NewRouter()
	r.Use(otelmux.Middleware(a.App))
	apiSubRouter := r.PathPrefix("/api/").Subrouter()
	vaultSubRoute := apiSubRouter.PathPrefix("/v1").Subrouter()
	vaultSubRoute.Path("/getAppRoles").Handler(token.ValidateMiddleware(a.getAppRoles(), a.T)).Queries("vault", "{vault}").Methods(http.MethodGet)
	vaultSubRoute.Path("/getValidRolesForUser").Handler(token.ValidateMiddleware(a.getValidRolesForUser(), a.T)).Queries("vault", "{vault}").Methods(http.MethodGet)
	vaultSubRoute.Path("/getAppRoleToken").Handler(token.ValidateMiddleware(a.getAppRoleToken(), a.T)).Queries("vault", "{vault}").Methods(http.MethodPut)
	vaultSubRoute.Path("/getVaults").Handler(token.ValidateMiddleware(a.getVaults(), a.T)).Methods(http.MethodGet)
	vaultSubRoute.Path("/getSecretNameList").Handler(token.ValidateMiddleware(a.getSecretNameList(), a.T)).Queries("vault", "{vault}", "team", "{team}", "env", "{env}", "app", "{app}").Methods(http.MethodGet)
	return r
}

// Формирование и возврат ответа
func Response(data *api.JSONResult, responseData bool, w http.ResponseWriter, ctx context.Context) {
	c, span := jarger.NewSpan(ctx, "Response", nil)
	defer span.End()
	l := token.GetLogCtx(c)
	w.Header().Set(DefaultCT[0], DefaultCT[1])
	var field interface{}
	if responseData {
		field = data.Data
	} else {
		field = data
	}
	resp, err := json.Marshal(field)
	if err != nil {
		msg := "Failed to convert data"
		l.WithError(err).Error(msg)
		span.RecordError(err)
		span.SetStatus(1, msg)
		http.Error(w, err.Error(), http.StatusInternalServerError)
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	w.WriteHeader(data.Code)
	span.SetAttributes(attribute.Key("reqId").String(token.GetReqIdCtx(ctx)))
	span.SetAttributes(attribute.Key("Code").Int(data.Code))
	span.SetAttributes(attribute.Key("Message").String(data.Message))
	intE, err := w.Write(resp)
	if err != nil {
		msg := "Failed to write response"
		l.WithError(err).Error(msg)
		span.RecordError(err)
		span.SetStatus(1, msg)
		http.Error(w, err.Error(), intE)
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	span.SetStatus(2, data.Message)

}
