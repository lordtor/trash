package vault

import (
	"context"
	"crypto/tls"
	"errors"
	"fmt"
	"net/http"
	"time"

	"vault-api/tools/common_lib"
	"vault-api/tools/pkg/logging"
	"vault-api/tools/siem"

	//	jarger "vault-api/tools/trace-lib"

	vault_api "github.com/hashicorp/vault/api"
	auth "github.com/hashicorp/vault/api/auth/approle"
)

var (
	httpClient = &http.Client{
		Timeout: 10 * time.Second,
	}
	Log = logging.Log
)

// Создание клиента vault сервера
func NewVault(ctx context.Context, con *VaultConfig, siemConfig siem.SiemConfig) (context.Context, Vault, error) {
	// Создание клиента
	ctx, cl := NewClient(ctx, con)
	//cl.SetToken(con.Token)
	vault := Vault{Conf: con, Client: cl, ctx: ctx, Siem: siemConfig}
	if con.Token == "" {
		if con.RoleId != "" && con.SecretId != "" {
			Log.Debug("GetAppRoleToken")
			t, err := vault.GetAppRoleToken(ctx, con.RoleId, con.SecretId)
			if err != nil {
				Log.Error(err)
				return ctx, vault, err
			}
			Log.Debug("SetToken")
			vault.Client.SetToken(t)
		} else {
			err := errors.New("error: need set vault root token or RoleId & SecretId")
			Log.Debugf("Role: %s", con.RoleId)
			Log.Debugf("Secret: %s", con.SecretId)
			Log.Error(err)
			return ctx, vault, err
		}

	} else {
		Log.Debug("SetToken")
		vault.Client.SetToken(con.Token)
	}

	return ctx, vault, nil
}

// Создание клиента
func NewClient(ctx context.Context, con *VaultConfig) (context.Context, *vault_api.Client) {
	tr := &http.Transport{
		TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
	}
	httpClient.Transport = tr
	client, err := vault_api.NewClient(&vault_api.Config{Address: con.Server, HttpClient: httpClient})
	if err != nil {
		Log.Errorf(err.Error())
	}
	//client.SetToken(con.Token)
	return ctx, client
}

// Получить все роли приложений
func (v *Vault) GetAppRoles(ctx context.Context) ([]string, error) {

	path := "/auth/token/roles/"
	approles, err := v.Client.Logical().List(path)
	if err != nil {

		Log.Errorf(err.Error())
		return nil, err
	}
	res, err := common_lib.ConvertInterfaceToSliceString(ctx, approles.Data["keys"])
	if err != nil {

		Log.Errorf(err.Error())
		return nil, err
	}

	return res, nil
}

// Получить список секретов приложения
func (v *Vault) GetListSecrets(ctx context.Context, cluster, team, env, app string) (res []string, err error) {
	if team == "" {
		team = "common"
	}
	if env == "" {
		err = errors.New("not set environment")
		Log.Errorf(err.Error())
	}
	if app == "" {
		err = errors.New("not set service")
		Log.Errorf(err.Error())
	}
	if err != nil {
		return nil, err
	}
	path := fmt.Sprintf("/%s/%s/%s/%s/%s/", v.Conf.BasePath, cluster, team, env, app)
	Log.Error(path)
	listSecrets, err := v.Client.Logical().List(path)
	if err != nil {
		Log.Error(err)
		return nil, err
	} else if listSecrets == nil {
		err = errors.New("error get list secrets")
		Log.Error(err)
		return nil, err
	}
	res, err = common_lib.ConvertInterfaceToSliceString(ctx, listSecrets.Data["keys"])
	if err != nil {
		Log.Error(err)
		return nil, err
	}
	return res, nil
}

// Установить новые значения для роли
func (v *Vault) SetAppRole(ctx context.Context, roleName string) (bool, error) {
	path := fmt.Sprintf("/auth/token/roles/%s", roleName)
	Log.Debug(v.Conf.Role)
	v.Conf.Role.RoleNme = roleName
	v.Conf.Role.PathSuffix = v.Conf.User.Email
	v.Conf.Role.AllowedEntityAliases = v.Conf.User.Email
	data := map[string]interface{}{}
	data["role_name"] = roleName
	data["allowed_policies"] = append(v.Conf.Role.AllowedPolicies, roleName)
	data["token_period"] = v.Conf.Role.TokenPeriod
	data["renewable"] = v.Conf.Role.Renewable
	data["token_explicit_max_ttl"] = v.Conf.Role.TokenExplicitMaxTtl
	data["token_type"] = v.Conf.Role.TokenType
	data["path_suffix"] = v.Conf.User.Email
	data["allowed_entity_aliases"] = v.Conf.User.Email
	groupApprole, err := v.Client.Logical().Write(path, data)
	if err != nil {
		Log.Error(err.Error())
		return false, err
	}
	Log.Debug(groupApprole)
	return true, nil
}

// Получение идентификатора роли
func (v *Vault) GetAppRoleId(ctx context.Context, roleName string) (string, error) {
	path := fmt.Sprintf("/auth/approle/role/%s/role-id", roleName)
	role_id, err := v.Client.Logical().Read(path)
	if err != nil {
		Log.Error(err.Error())
		return "", err
	}
	id := string(role_id.Data["role_id"].(string))
	return id, nil
}

// Получение секретного идентификатора роли
func (v *Vault) GetAppRoleSecretId(ctx context.Context, roleName string, roleId string) (string, error) {
	path := fmt.Sprintf("/auth/approle/role/%s/secret-id", roleName)
	data := map[string]interface{}{}
	data["metadata"] = fmt.Sprintf("{ \"group\": \"%s\",\"name\":\"%s\",\"ip\":\"%s\",\"mail\":\"%s\" }",
		roleName, v.Conf.User.UserName, v.Conf.User.IP, v.Conf.User.Email)
	data["role_id"] = roleId
	secret_id, err := v.Client.Logical().Write(path, data)
	if err != nil {
		Log.Error(err.Error())
		return "", err
	}
	id := string(secret_id.Data["secret_id"].(string))
	return id, nil
}

// Получение токена авторизации роли
func (v *Vault) GetAppRoleToken(ctx context.Context, roleId string, secretId string) (string, error) {
	secretID := &auth.SecretID{FromString: secretId}
	Log.Debug("NewAppRoleAuth")
	appRoleAuth, err := auth.NewAppRoleAuth(
		roleId,
		secretID,
	)
	if err != nil {
		if err != nil {
			Log.Errorf("Unable to initialize AppRole auth method: %w", err)
			return "", err
		}
	}
	Log.Debug("Login")
	authInfo, err := v.Client.Auth().Login(ctx, appRoleAuth)
	if err != nil {
		Log.Errorf("Unable to login to AppRole auth method: %w", err)
		return "", err
	}
	if authInfo == nil {
		Log.Error("No auth info was returned after login")
		return "", err
	}
	if v.Conf.RoleId != roleId && v.Siem.Enabled {

		l := SiemLog{
			VaultId:  v.Conf.Server,
			RoleID:   roleId,
			UserName: v.Conf.User.UserName,
			Email:    v.Conf.User.Email,
			IP:       v.Conf.User.IP,
		}
		Log.Trace(l)
		err = siem.Syslog(&v.Siem, l)
		if err != nil {
			Log.Error(err)
		}
	}

	return authInfo.Auth.ClientToken, nil
}

// Получить доступные роли для пользователя
func (v *Vault) GetValidRolesForUser(ctx context.Context) ([]string, error) {
	var validRoles []string
	roles, err := v.GetAppRoles(ctx)
	if err != nil {
		Log.Error(err.Error())
		return nil, err
	}
	listRoles, err := common_lib.ConvertInterfaceToSliceString(ctx, roles)
	if err != nil {
		Log.Error(err.Error())
		return nil, err
	}
	for groupId := range v.Conf.User.GroupeNames {
		if common_lib.CheckStingSliceContain(ctx, listRoles, v.Conf.User.GroupeNames[groupId]) {
			validRoles = append(validRoles, v.Conf.User.GroupeNames[groupId])
		}
	}
	return validRoles, nil
}
